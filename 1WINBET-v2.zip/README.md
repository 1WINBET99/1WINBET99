# TEMO BET v2 — Sportsbook + Casino Demo

A responsive educational prototype inspired by modern sportsbook/casino interfaces.

### Included
- Sportsbook event listings and demo odds
- Bet slip and virtual settlement
- Casino lobby
- 3-reel slot demo
- Demo account screen
- Mobile-friendly dark UI
- No external database or payment integration

### Important
This is **not** a real-money gambling platform. It does not accept deposits, process withdrawals, or award cash/value. All balances and bets are virtual.

Before operating real-money gambling, obtain the required authorization/licence for the relevant jurisdiction and implement applicable KYC/age verification, AML, responsible-gambling, security, audit, geolocation/player restrictions, and approved payment arrangements.

### Run
Open `index.html` in a browser, or publish the files with GitHub Pages.
